"""Top-level package for dwrpy."""

__author__ = """Hamid Ali Syed"""
__email__ = 'hamidsyed37@gmail.com'
__version__ = '0.1.0'
